package com.example.assignment

data class ApiResponse(
    val title: String,
    val description: String
)

