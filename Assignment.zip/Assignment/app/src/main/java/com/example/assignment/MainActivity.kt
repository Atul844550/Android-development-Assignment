package com.example.assignment

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import javax.security.auth.callback.Callback

class MainActivity : AppCompatActivity() {

    private lateinit var titleTextView: TextView
    private lateinit var descriptionTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        titleTextView = findViewById(R.id.title)
        descriptionTextView = findViewById(R.id.description)

        // Launch coroutine to fetch data
        lifecycleScope.launch {
            fetchData()
        }
    }

    private suspend fun fetchData() {
        try {
            // Use Retrofit to get data
            val data = RetrofitInstance.api.getData()

            // Update UI on the main thread
            titleTextView.text = data.title
            descriptionTextView.text = data.description
        } catch (e: Exception) {
            e.printStackTrace()
            titleTextView.text = "Master Android Development with Step-by-Step Tutorials"
            descriptionTextView.text =
                "Unlock the Secrets of Android Development with Expert Guidance description Get ready to become an Android development pro with our comprehensive tutorial series. From beginner to advanced topics, we'll guide you through every step of the process, ensuring you gain a deep understanding of Android app development. Join us today and unleash your creativity!"
        }
    }
}






