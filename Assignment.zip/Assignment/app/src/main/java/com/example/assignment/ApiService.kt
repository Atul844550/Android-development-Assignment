package com.example.assignment

import retrofit2.http.GET

interface ApiService {
    @GET("6HBE")
    suspend fun getData(): ApiResponse
}
